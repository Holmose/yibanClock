package schedule

import "testing"

func TestAddUserToQMysql(t *testing.T) {
	AddUserToQByMysql()
}
