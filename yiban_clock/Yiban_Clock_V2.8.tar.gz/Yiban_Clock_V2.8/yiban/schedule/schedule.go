package schedule

import (
	"Yiban_Clock/yiban/browser"
	"Yiban_Clock/yiban/config"
	"log"
)

var userCount = 0

// 控制协程数量
var pool chan struct{}

// ScheduleSim 统一分配个人浏览器
func ScheduleSim(browserQ []*browser.Browser) {

	// 最大协程数
	pool = make(chan struct{}, config.MaxNum)
	go func() {
		for {
			pool <- struct{}{}
		}
	}()

	log.Printf("当前用户总数：%v", userCount)

	for {
		if len(browserQ) < 1 {
			break
		}
		b := browserQ[0]
		browserQ = browserQ[1:]
		wg.Add(1)
		go Run(b)
	}
	wg.Wait()
}
