package sqlitecnn

import (
	"database/sql"
	"fmt"
	"log"
	"testing"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

func TestRun(t *testing.T) {
	// 打开/创建
	db, err := sql.Open("sqlite3",
		"C:\\Users\\holmose\\GolandProjects\\Yiban_Clock\\webOA\\sqlitecnn\\db.sqlite3")
	// 关闭
	defer db.Close()

	rows, err := db.Query("SELECT * FROM yiban_yiban")
	if err != nil {
		log.Panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var uid int
		var name string
		var created time.Time
		err = rows.Scan(&uid, &name, &created)
		if err != nil {
			log.Panic(err)
		}

		fmt.Println(uid)
		fmt.Println(name)
		fmt.Println(created)
	}
}
