package ecryption

type Params struct {
	WFId   string
	Data   interface{}
	Extend interface{}
}
