package clockOne

import (
	"Yiban_Clock/yiban/schedule"
	"errors"
	"log"
)

// Service.Method

type ClockService struct{}

type Args struct {
	Key string
	Iv  string
}

func (ClockService) Clock(args Args, result *string) error {
	defer func() {
		if err := recover(); err != nil {
			log.Println("err错误：", err)
		}
	}()
	// 合法性判断
	if args.Key != "hFjCM5XBMC6bo3k" && args.Iv != "hONmvJHk" {
		return errors.New("secret key error")
	}
	// 执行打卡
	schedule.ChanListRunMysql()
	*result = "打卡任务执行结束！"
	return nil
}

// {"method":"ClockService.Clock","params":[{"Key":"hFjCM5XBMC6bo3k","Iv":"hONmvJHk"}],"id":1}
