package main

import (
	"Yiban_Clock/clockOne"
	"fmt"
	"net"
	"net/rpc/jsonrpc"
)

func main() {
	conn, err := net.Dial("tcp", "yiban:1234")
	if err != nil {
		panic(err)
	}
	client := jsonrpc.NewClient(conn)
	var result string
	err = client.Call("ClockService.Clock",
		clockOne.Args{Key: "hFjCM5XBMC6bo3k", Iv: "hONmvJHk"}, &result)
	if err != nil {
		panic(err)
	} else {
		fmt.Println(result)
	}
}
