package main

import (
	"Yiban_Clock/clockOne"
	"fmt"
	"log"
	"net"
	"net/rpc"
	"net/rpc/jsonrpc"
)

func main() {
	err := rpc.Register(clockOne.ClockService{})
	if err != nil {
		log.Panic(err)
	}
	fmt.Println("ClockOne Server Listening 0.0.0.0:1234 ...")
	listen, err := net.Listen("tcp", ":1234")
	if err != nil {
		log.Panic(err)
	}
	for {
		conn, err := listen.Accept()
		if err != nil {
			log.Println(err)
			continue
		}
		// 正在执行时不接收其他请求
		jsonrpc.ServeConn(conn)
	}
}
