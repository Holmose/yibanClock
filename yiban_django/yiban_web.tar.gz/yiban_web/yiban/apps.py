from django.apps import AppConfig


class YibanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'yiban'
    verbose_name = '健康打卡'
