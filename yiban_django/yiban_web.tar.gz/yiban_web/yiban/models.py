from django.db import models
from croniter import croniter
from datetime import datetime
import django.utils.timezone as timezone
from django.forms import ValidationError

# Create your models here.
class Yiban(models.Model):
    username = models.CharField(verbose_name="登录用户", max_length=20, blank=False, unique=True)
    name = models.CharField(verbose_name="备注", max_length=5, blank=True)
    password = models.CharField(verbose_name="密码", max_length=30, blank=False)
    e_mail = models.CharField(verbose_name="电子邮箱", max_length=30, blank=False)
    verify = models.CharField(verbose_name="Verify", max_length=2000, blank=True)
    day = models.PositiveIntegerField(verbose_name="剩余天数", blank=False)
    address = models.CharField(verbose_name="当前位置", max_length=20, blank=False, default="云南省曲靖市麒麟区")
    status_choice = (
        (0, '否'),
        (1, '是'),
    )
    status = models.IntegerField(choices=status_choice, verbose_name="是否使用身体状况采集", blank=False, default=0)
    clock_crontab = models.CharField(verbose_name="定时规则", max_length=20, blank=True)
    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    class Meta:
        verbose_name = "用户管理"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username[-5:]+"\t"+self.name
    # 定时规则检查
    def clean(self):
        if self.clock_crontab:
            try:
                croniter(self.clock_crontab, datetime.now())
            except Exception as e:
                raise ValidationError('定时规则用法（仅支持五位）：* * * * * 分 时 日 月 周')

# Create your models here.
class Task(models.Model):
    yiban = models.ForeignKey(Yiban, verbose_name="用户缩写",on_delete=models.CASCADE, blank=False)
    name = models.CharField(verbose_name="任务名称", max_length=30, blank=False)
    datetime = models.DateTimeField(verbose_name="打卡时间", max_length=30, blank=False, default=timezone.now)
    position = models.CharField(verbose_name="打卡位置", max_length=200, blank=False)
    position_num = models.CharField(verbose_name="位置坐标", max_length=50, blank=False)
    result_choice = (
        (0, '失败'),
        (1, '成功'),
    )
    result = models.IntegerField(choices=result_choice, verbose_name="打卡结果", blank=False, default=0)
    message = models.CharField(verbose_name="返回信息", max_length=50, blank=False, default='')

    class Meta:
        verbose_name = "任务记录"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.yiban.username

# 存储历史打卡FormData_list表单Json数据
class FormData(models.Model):
    yiban = models.ForeignKey(Yiban, verbose_name="用户",on_delete=models.CASCADE, blank=False)
    name = models.CharField(verbose_name="任务名称", max_length=30, blank=False)
    datetime = models.DateTimeField(verbose_name="表单时间", max_length=30, blank=False, default=timezone.now)
    address = models.CharField(verbose_name="打卡位置", max_length=200, blank=False)
    # 加密表单
    data = models.TextField(verbose_name="表单数据", max_length=5000, blank=False)
    status_choice = (
        (0, '否'),
        (1, '是'),
    )
    status = models.IntegerField(choices=status_choice, verbose_name="是否为假期表单", blank=False, default=0)

    class Meta:
        verbose_name = "表单记录"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name
