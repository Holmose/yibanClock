from django.contrib import admin
from django.utils.translation import gettext_lazy
from django.contrib.auth.admin import UserAdmin

# Register your models here.
from . import models
from django import forms

class YibanModelAdmin(admin.ModelAdmin):
    model = models.Yiban
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(username=request.user)

class TaskModelAdmin(admin.ModelAdmin):
    model = models.Yiban
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs

        return qs.filter(yiban__username=request.user)

class FormDataModelAdmin(admin.ModelAdmin):
    model = models.Yiban
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(username=request.user)

class YibanRE(FormDataModelAdmin):
    list_display = ['username', 'name', 'e_mail', 'day']
    list_filter = ['name', 'day']

class TaskRE(TaskModelAdmin):
    list_display = ['yiban', 'datetime', 'result', 'message']
    list_filter = ['yiban', 'name', 'result']

class FormDataRE(FormDataModelAdmin):
    list_display = ['yiban', 'name', 'datetime', 'status']
    list_filter = ['yiban', 'name', 'datetime', 'status']

admin.site.site_header = '定时打卡系统'
admin.site.site_title = '定时打卡'
admin.site.register(models.Yiban, YibanRE)
admin.site.register(models.Task, TaskRE)
admin.site.register(models.FormData, FormDataRE)
