from django.http import HttpResponse

def hello(request):   # 函数视图
    return HttpResponse("<h1>欢迎使用！！！</h1>")
